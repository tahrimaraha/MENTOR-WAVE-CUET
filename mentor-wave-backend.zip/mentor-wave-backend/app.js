const express = require("express");
const cors = require("cors");

const app = express();

app.use(cors());
app.use(express.json());

app.get("/", (req, res) => {
  res.send("Mentor Wave API Running");
});

// Routes
app.use("/api/auth", require("./routes/authRoutes"));
app.use("/api/users", require("./routes/userRoutes"));
app.use("/api/tuition", require("./routes/tuitionRoutes"));
app.use("/api/applications", require("./routes/applicationRoutes"));

module.exports = app;