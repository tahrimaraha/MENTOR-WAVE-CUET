const { DataTypes } = require("sequelize");
const { sequelize } = require("../config/db");

const TuitionPost = sequelize.define("TuitionPost", {
  title: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  studentClass: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  subject: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  location: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  budget: {
    type: DataTypes.STRING,
  },
  description: {
    type: DataTypes.TEXT,
  },
  status: {
    type: DataTypes.ENUM("open", "filled"),
    defaultValue: "open",
  }
});

module.exports = TuitionPost;