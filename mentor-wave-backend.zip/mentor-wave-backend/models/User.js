const { DataTypes } = require("sequelize");
const { sequelize } = require("../config/db");

const User = sequelize.define("User", {
  name: DataTypes.STRING,
  email: {
    type: DataTypes.STRING,
    unique: true,
  },
  password: DataTypes.STRING,
  role: {
    type: DataTypes.ENUM("tutor", "guardian", "admin"),
    defaultValue: "tutor",
  },
}, {
  // Security Layer: Hides password from all queries by default
  defaultScope: {
    attributes: { exclude: ['password'] },
  },
  scopes: {
    // Used specifically for login to bypass the exclusion
    withPassword: {
      attributes: {},
    }
  }
});

module.exports = User;