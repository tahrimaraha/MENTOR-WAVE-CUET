const { sequelize } = require("../config/db");
const User = require("./User");
const TutorProfile = require("./TutorProfile");
const TuitionPost = require("./TuitionPost");
const Application = require("./Application");

// --- Relationships ---

// 1. User & TutorProfile (1-to-1)
User.hasOne(TutorProfile, { foreignKey: "UserId", onDelete: "CASCADE" });
TutorProfile.belongsTo(User, { foreignKey: "UserId" });

// 2. User & TuitionPost (1-to-Many)
// A Guardian (User) creates many Tuition Posts
User.hasMany(TuitionPost, { foreignKey: "guardianId", onDelete: "CASCADE" });
TuitionPost.belongsTo(User, { as: "guardian", foreignKey: "guardianId" });

// 3. User & Application (1-to-Many)
// A Tutor (User) submits many Applications
User.hasMany(Application, { foreignKey: "tutorId", onDelete: "CASCADE" });
Application.belongsTo(User, { as: "tutor", foreignKey: "tutorId" });

// 4. TuitionPost & Application (1-to-Many)
// A Job Post receives many Applications
TuitionPost.hasMany(Application, { onDelete: "CASCADE" });
Application.belongsTo(TuitionPost);

// --- Sync Function ---
const syncDB = async () => {
  try {
    /**
     * NOTE: We are using { force: true } to solve the "Data truncated" 
     * and "Foreign Key" errors. This will DROP all existing tables 
     * and recreate them. 
     * * IMPORTANT: Once your PATCH command works in Postman, 
     * change this back to { alter: true }.
     */
    await sequelize.sync({ force: true }); 
    console.log("✅ Database Reset: All tables recreated successfully.");
  } catch (err) {
    console.error("❌ Database sync failed:", err.message);
  }
};

module.exports = {
  User,
  TutorProfile,
  TuitionPost,
  Application,
  syncDB,
  sequelize
};