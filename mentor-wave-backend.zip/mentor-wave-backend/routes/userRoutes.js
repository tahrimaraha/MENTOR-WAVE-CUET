const router = require("express").Router();
const protect = require("../middleware/authMiddleware");
const { getProfile, updateTutorProfile } = require("../controllers/userController");

// Fetch profile (Now includes TutorProfile details)
router.get("/profile", protect, getProfile);

// Create or Update Tutor details
router.post("/profile/tutor", protect, updateTutorProfile);

module.exports = router;