const router = require("express").Router();
const protect = require("../middleware/authMiddleware");
const { createTuition, getAllTuition } = require("../controllers/tuitionController");

// Post a tuition (must have a token)
router.post("/", protect, createTuition);

// See all tuitions (must have a token)
router.get("/", protect, getAllTuition);

module.exports = router;