const bcrypt = require("bcryptjs");
const { User } = require("./models");
const { sequelize } = require("./config/db");

const seedData = async () => {
  try {
    const password = await bcrypt.hash("12345678", 10);

    const accounts = [
      { name: "Laiba Tabassum", email: "u2204077@student.cuet.ac.bd", password, role: "admin" },
      { name: "Tahrima Jahan", email: "u2204078@student.cuet.ac.bd", password, role: "admin" },
      { name: "Srabon Das", email: "u2204096@student.cuet.ac.bd", password, role: "admin" }
    ];

    console.log("🌱 Seeding database...");

    for (const account of accounts) {
      const [user, created] = await User.findOrCreate({
        where: { email: account.email },
        defaults: account
      });

      if (!created) {
        // If they already exist, ensure they are set to 'admin'
        user.role = "admin";
        await user.save();
        console.log(`updated ${account.name} to admin`);
      } else {
        console.log(`created admin: ${account.name}`);
      }
    }

    console.log("✅ Seeding complete!");
    process.exit();
  } catch (err) {
    console.error("❌ Seeding error:", err);
    process.exit(1);
  }
};

seedData();