const { TuitionPost, User } = require("../models");

exports.createTuition = async (req, res) => {
  try {
    const post = await TuitionPost.create({
      ...req.body,
      guardianId: req.user.id, // Links the post to the person logged in
    });
    res.status(201).json(post);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.getAllTuition = async (req, res) => {
  try {
    const posts = await TuitionPost.findAll({
      where: { status: "open" },
      include: [{
        model: User,
        as: "guardian",
        attributes: ["name", "email"] // Shows who posted it
      }]
    });
    res.json(posts);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};