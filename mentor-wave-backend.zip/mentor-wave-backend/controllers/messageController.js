const { Message } = require("../models");

exports.sendMessage = async (req, res) => {
  const message = await Message.create({
    ...req.body,
    senderId: req.user.id,
  });

  res.json(message);
};