const bcrypt = require("bcryptjs");
const { User } = require("../models");
const generateToken = require("../utils/generateToken");

// Validation helper
const isValidCUETEmail = (email) => {
  return email.endsWith("@student.cuet.ac.bd");
};

exports.register = async (req, res) => {
  try {
    const { name, email, password, role } = req.body;

    // 1. Logic Check: Only Tutors MUST use CUET email
    if (role === "tutor" && !isValidCUETEmail(email)) {
      return res.status(400).json({ message: "Tutors must use a CUET student email" });
    }

    // 2. Security Check: Prevent manual 'admin' registration
    if (role === "admin") {
      return res.status(403).json({ message: "Admin registration is restricted" });
    }

    // 3. Check if user already exists
    const existingUser = await User.findOne({ where: { email } });
    if (existingUser) {
      return res.status(400).json({ message: "Email already registered" });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const user = await User.create({
      name,
      email,
      password: hashedPassword,
      role: role || "tutor",
    });

    const token = generateToken(user);

    // Convert to JSON and remove password (even though defaultScope handles it)
    const userResponse = user.toJSON();
    delete userResponse.password;

    res.status(201).json({ user: userResponse, token });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;

    // IMPORTANT: Use scope("withPassword") to get the password for verification
    const user = await User.scope("withPassword").findOne({ where: { email } });
    
    if (!user) return res.status(404).json({ message: "User not found" });

    const match = await bcrypt.compare(password, user.password);
    if (!match) return res.status(400).json({ message: "Wrong password" });

    const token = generateToken(user);

    // Remove password from response
    const userResponse = user.toJSON();
    delete userResponse.password;

    res.json({ user: userResponse, token });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};